function disableCheckBoxes() {
    if (document.selectAccount != null) {
        if (document.selectAccount.accountType[0].checked) {
            document.selectAccount.echelonAccount.disabled = true;
            document.selectAccount.echBTMlAccount.disabled = true;
            document.selectAccount.echOptAccount.disabled = true;
            document.selectAccount.echLeMlAccounts.disabled = true;
            document.selectAccount.echLeMeOptAccount.disabled = true;

            document.selectAccount.sInsAccount.disabled = false;
            document.selectAccount.sMLAccount.disabled = false;
            document.selectAccount.sOptionsAccount.disabled = false;

            document.selectAccount.echelonAccount.checked = false;
            document.selectAccount.echBTMlAccount.checked = false;
            document.selectAccount.echOptAccount.checked = false;
            document.selectAccount.echLeMlAccounts.checked = false;
            document.selectAccount.echLeMeOptAccount.checked = false;

        } else {
            document.selectAccount.echelonAccount.disabled = false;
            document.selectAccount.echBTMlAccount.disabled = false;
            document.selectAccount.echOptAccount.disabled = false;
            document.selectAccount.echLeMlAccounts.disabled = false;
            document.selectAccount.echLeMeOptAccount.disabled = false;

            document.selectAccount.sInsAccount.checked = false;
            document.selectAccount.sMLAccount.checked = false;
            document.selectAccount.sOptionsAccount.checked = false;

            document.selectAccount.sInsAccount.disabled = true;
            document.selectAccount.sMLAccount.disabled = true;
            document.selectAccount.sOptionsAccount.disabled = true;
        }
    }
}

function showPDF(box, pdf, windowName) {
    var openedWindow;
    l = (screen.availWidth - 10 - 600) / 2;
    t = (screen.availHeight - 20 - 500) / 2;

    if (box.checked) {
        openedWindow = window.open(pdf, windowName, 'width=600,height=500,left=' + l + ',top=' + t + ',menubar=yes,resizable=yes');
    }
}

function enableAccount() {
    document.applicationForm.bankAccountName.disabled = false;
    document.applicationForm.bankBsbNumber.disabled = false;
    document.applicationForm.bankAccountNumber.disabled = false;
}

function disableAccountAndEmpty() {
    document.applicationForm.bankAccountName.value = '';
    document.applicationForm.bankBsbNumber.value = '';
    document.applicationForm.bankAccountNumber.value = '';
    disableAccount();
}

function disableAccount() {
    document.applicationForm.bankAccountName.disabled = true;
    document.applicationForm.bankBsbNumber.disabled = true;
    document.applicationForm.bankAccountNumber.disabled = true;
}

function setAccount() {
    if (document.applicationForm.radiodd.checked) {
        enableAccount();
    } else {
        disableAccount();
    }
}

addLoadEvent(disableCheckBoxes);
