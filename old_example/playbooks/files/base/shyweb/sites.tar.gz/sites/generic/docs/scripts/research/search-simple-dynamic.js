/**
 * Enables or disables the value input depending on the field selected,
 * that is ensure that the correct value type is selected based on the field.
 *
 * @param form  The form which contains the 'Field', 'valueType' and 'userValue' elements
 *              'valueType' has to be a radio button
 *              'Field' has to be an option list
 */
function checkValueType(formUser, valuetype) {
  selectedField = formUser.Field.options[formUser.Field.selectedIndex].text;
  selectedCriterion = formUser.Criterion.options[formUser.Criterion.selectedIndex].text;
  if ( (selectedCriterion == "Less than") || (selectedCriterion == "Greater than") || (selectedCriterion == "Equal to")) {
    if  ((selectedField=="Industry")
          || (selectedField=="Home Office State")
          || (selectedField=="Recommendation")
          || (selectedField=="GICS Sector")
          || (selectedField=="GICS Industry Group")
          || (selectedField=="Value Rank")
          || (selectedField=="Risk Rank")
          || (selectedField=="Income Rank")
          || (selectedField=="Growth Rank")) {
      clearUserValue(formUser);
      formUser.ValueType[1].checked=true;
      clearComparison(formUser);
      checkValueList(formUser);
    } else if (valuetype=="user") {
      formUser.ValueType[0].checked=true;
    } else if (valuetype=="comparison") {
      //formUser.ValueType[2].checked=true;
    }
  } else {
    clearUserValue(formUser);
    clearPredefinedValue(formUser);
    clearComparison(formUser);
  }
}

function editField(formEngine, formUser) {
  var editIndex = formUser.QueryList.selectedIndex;
  if (editIndex == -1) alert('Please select a valid query entry.');
  else if (editIndex > findNextAvailableIndex(formEngine)) editIndex = findNextAvailableIndex(formEngine)
  else {
   // formUser.editFieldIndex.value = editIndex;
    currentUserQueryIndex = editIndex;
    parse(formEngine.userqueries[editIndex].value);
    for (i=0; i<formUser.Category.length ; i++) {
      if (formUser.Category.options[i].text == strElements[0]) {
        formUser.Category.selectedIndex = [i];
        updateField(formUser.Category,formUser.Field);
      }
    }
    for (i=0; i<formUser.Field.length ; i++) {
      if (formUser.Field.options[i].text == strElements[1]) {
        formUser.Field.selectedIndex = [i];
        updateValue(formUser)
      }
    }
    for (i=0; i<formUser.Criterion.length ; i++) {
      if (formUser.Criterion.options[i].text == translateCriterionOutIn(strElements[2])) {
        formUser.Criterion.selectedIndex = [i];
      }
    }
    if (strElements[3] == "novalue") {
      clearUserValue(formUser);
      clearPredefinedValue(formUser);
      clearComparison(formUser);
    } else if (strElements[3] == "user") {
      formUser.ValueType[0].checked = true;
      clearPredefinedValue(formUser);
      clearComparison(formUser);
      formUser.UserValue.value = strElements[4];
    } else if (strElements[3] == "predefined") {
      clearUserValue(formUser);
      formUser.ValueType[1].checked = true;
      clearComparison(formUser);
      for (i=0; i<formUser.SelectValue.length ; i++) {
        if (formUser.SelectValue.options[i].text == strElements[4]) {
          formUser.SelectValue.selectedIndex = [i];
        }
      }
    } else if (strElements[3] == "comparison") {
      clearUserValue(formUser);
      clearPredefinedValue(formUser);
      //formUser.ValueType[2].checked = true;
      formUser.Factor.value = strElements[4];
      for (i=0; i<formUser.CategoryC.length ; i++) {
        if (formUser.CategoryC.options[i].text == strElements[5]) {
          formUser.CategoryC.selectedIndex = [i];
          updateField(formUser.CategoryC,formUser.FieldC);
        }
      }
      for (i=0; i<formUser.FieldC.length ; i++) {
        if (formUser.FieldC.options[i].text == strElements[6]) {
          formUser.FieldC.selectedIndex = [i];
        }
      }
    }
  }
}