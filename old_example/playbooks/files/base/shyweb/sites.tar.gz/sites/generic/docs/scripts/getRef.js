// use this  instead of getElementById ... as it allows different ways to obtain the 
// element, so that it will be compatible with firefox!  This is a work around to be able
// to use javascript, where we want to reference a struts NAMEd item.
function getRef(name) { 
             var ref = document.all[name];
             if (ref == null) {
                        ref = document.getElementById(name); 
             }           
            return ref; 
}

