//
// POPUPONEXIT.JS
// Popup-on-exit script library
//
// Ron MacNeil
// March 2005
//


// -- Settings ----------------------------------------------------------------
                           http://www.investmenttrends.com.au/surveys/cfd06wb.html
// URL to pop up when user leaves the site or closes the browser
POPUPONEXIT_URL = "/do/public/inviteSurvey";

// URL of upfront opt-in page (change if not in the same dir as other files)
// Set to "" to disable upfront opt-in
//POPUPONEXIT_OPTIN_URL = "optin.htm";
POPUPONEXIT_OPTIN_URL = "";

// Probability (number between 0 and 1) of popup occurring
POPUPONEXIT_PROBABILITY = 0.5;

// Home URLs
// One or more URLs that, together, comprise "home".  If the user navigates
// outside of these URL's (and those beneath them), they will be deemed
// to have "exited", and will at that point be considered for the popup.
// Entries:
// - "domain/path" format (no "http(s)://" before domain)
// - domain may be omitted, which means "this domain"
// - "" or "/" mean "root of this domain"
POPUPONEXIT_HOME_URLS = [
	"/"
];

// Popup window sizes
POPUPONEXIT_WIDTH=600;
POPUPONEXIT_HEIGHT=300;

// Popup window options (consult a javascript reference for more info)
POPUPONEXIT_WINDOWOPTIONS = "width=" + POPUPONEXIT_WIDTH + ",height=" + POPUPONEXIT_HEIGHT + ",top=20,left=20,resizable=1,scrollbars=yes,status=yes,menubar=yes";

// URL of 'popuponexit.htm' monitoring page (change if not in the same dir as other files)
POPUPONEXIT_MONITORURL = "/do/secure/survey";

// Monitoring page polling interval (in milliseconds)
POPUPONEXIT_MONITORINTERVAL = 1000;

// Name of monitoring cookie
POPUPONEXIT_MONITORCOOKIE = "poemonitoringAug";

// Name of popup-shown cookie
POPUPONEXIT_SHOWNCOOKIE = "wbc-cfd-200703107";

// Name of opt-in cookie
POPUPONEXIT_OPTINCOOKIE = "wbc-cfd-20070310";

// Lifetime (in months) of cookies
POPUPONEXIT_COOKIELIFETIME = 2;

// ----------------------------------------------------------------------------


function POPUPONEXIT_Trim( s )
{
	var i = 0;
	while( true ) {
		if( s.charAt(0) == " " ) {
			s = s.substring(1,s.length);
		} else {
			break;
		}
	}
	while( true ) {
		if( s.charAt(s.length-1) == " " ) {
			s = s.substring(0,s.length-1);
		} else {
			break;
		}
	}
	return s;
}


function POPUPONEXIT_SetCookie( name, value, expires, path )
{
	if( name == null ) name = "defaultcookie";
	if( value == null ) value = "defaultvalue";
	// pass null for expires for a session-only cookie
	if( path == null ) path = "/";
	var s = "";
	s += escape( name ) + "=" + escape( value );
	if( expires ) {
		s += ";EXPIRES=" + expires.toGMTString();
	}
	s += ";PATH=" + path;
	document.cookie = s;
	// "name=value;EXPIRES=Sun, 01-Feb-04 00:00:00 GMT;PATH=/";
}


function POPUPONEXIT_GetCookies()
{
    var cookiedata = new Object();
	var s = ( document.cookie || "" ) + "";
	var a = s.split( ";" );
	var a2, key, value;
	for( var i = 0; i < a.length; i++ ) {
		a2 = a[i].split( "=" );
		key = POPUPONEXIT_Trim( ( a2[0] || "" ) + "" );
		value = POPUPONEXIT_Trim( ( a2[1] || "" ) + "" );
		if( key != "" && value != "" ) {
			cookiedata[key] = value;
		}
	}
    return cookiedata;
}


function POPUPONEXIT_Initialize()
{
    var cookiejar = POPUPONEXIT_GetCookies();
	if( cookiejar[POPUPONEXIT_MONITORCOOKIE] != "true" && cookiejar[POPUPONEXIT_SHOWNCOOKIE] != "true" ) {
		window.open( POPUPONEXIT_MONITORURL, "", "width=1,height=1,top=3000,left=3000" );
		POPUPONEXIT_SetCookie( POPUPONEXIT_MONITORCOOKIE, "true" );
		if( POPUPONEXIT_OPTIN_URL && POPUPONEXIT_OPTIN_URL != "" ) {
			window.open( POPUPONEXIT_OPTIN_URL, "", POPUPONEXIT_WINDOWOPTIONS );
		} else {
			self.focus();
		}
	}
}


function POPUPONEXIT_InitializeMonitor()
{
	var cookiejar = POPUPONEXIT_GetCookies();
	if(  cookiejar[POPUPONEXIT_SHOWNCOOKIE] == "true" ) {
		window.close();
		return;
	}
	setTimeout( "POPUPONEXIT_MonitorTick()", POPUPONEXIT_MONITORINTERVAL );
}


function POPUPONEXIT_Optin()
{
	var expires = new Date();
	expires.setMonth( expires.getMonth() + POPUPONEXIT_COOKIELIFETIME );
	POPUPONEXIT_SetCookie( POPUPONEXIT_OPTINCOOKIE, "true", expires );
}


function POPUPONEXIT_Popup()
{
    var cookiejar = POPUPONEXIT_GetCookies();
	var expires = new Date();
	var popupwindow = null;
	expires.setMonth( expires.getMonth() + POPUPONEXIT_COOKIELIFETIME );
	POPUPONEXIT_SetCookie( POPUPONEXIT_SHOWNCOOKIE, "true", expires );
	if(
		POPUPONEXIT_OPTIN_URL
		&& POPUPONEXIT_OPTIN_URL != ""
		&& cookiejar[POPUPONEXIT_OPTINCOOKIE] != "true"
	) {
		// (they didn't opt in)
	} else {
		if( Math.random() < POPUPONEXIT_PROBABILITY ) {
			popupwindow = window.open( POPUPONEXIT_URL, "", POPUPONEXIT_WINDOWOPTIONS );
			popupwindow.focus();
		}
	}
    window.close();
}


function POPUPONEXIT_MonitorTick()
{
	var oldonerror = null;
	var thisdomain = "";
	var curdomain = "";
	var curpath = "";
	var cururl = "";
	var homeurl = "";
	var presentpopup;
	var i;

	oldonerror = window.onerror;
	window.onerror = POPUPONEXIT_Popup;

	presentpopup = true;
	if( top.opener ) {
		thisdomain = top.document.domain;
		curdomain = top.opener.document.domain;
		curpath = top.opener.location.pathname;
		cururl = curdomain + curpath;
		for( i=0; i<POPUPONEXIT_HOME_URLS.length; i++ ) {
			homeurl = POPUPONEXIT_HOME_URLS[ i ];
			if( homeurl == "" ) {
				homeurl = "/";
			}
			if( homeurl.substr( 0, 1 ) == "/" ) {
				homeurl = thisdomain + homeurl;
			}
			if( homeurl.indexOf( "/" ) < 0 ) {
				homeurl += "/";
			}
			if(
				cururl.substr( 0, homeurl.length ).toUpperCase()
				== homeurl.toUpperCase()
			) {
				presentpopup = false;
				setTimeout(
					"POPUPONEXIT_MonitorTick()",
					POPUPONEXIT_MONITORINTERVAL
				);
				break;
			}
		}
	}

	if( presentpopup ) {
		POPUPONEXIT_Popup();
	}

	if( oldonerror != null ) {
		window.onerror = oldonerror;
	}
}
