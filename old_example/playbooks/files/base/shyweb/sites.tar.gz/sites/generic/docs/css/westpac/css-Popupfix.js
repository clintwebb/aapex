// popup window name
var visitorSellsISS;
var visitorSellsCN;

// returns string "invalid" if it cant compute.
// parameter t - tag name
// property p  - property name
function getComputedPropertyValue(t, p) {
	var propvalue = "invalid";
	foundElem = document.getElementsByTagName(t).item(0);
	if (document.defaultView && document.defaultView.getComputedStyle) {
		propvalue = document.defaultView.getComputedStyle(foundElem , null).getPropertyValue(p) ;
	}
	return propvalue;
}

// ugly workaround for missing support for selectorText in Netscape6/Mozilla
// call onLoad() or before you need to do anything you would have otherwise used
// selectorText for.
var ugly_selectorText_workaround_flag = false;
var allStyleRules;
// code developed using the following workaround (CVS v1.15) as an example.
// http://lxr.mozilla.org/seamonkey/source/extensions/xmlterm/ui/content/XMLTermCommands.js
function ugly_selectorText_workaround() {
	if((navigator.userAgent.indexOf("Gecko") == -1) ||
	   (ugly_selectorText_workaround_flag)) {
		return; // we've already been here or shouldn't be here
	}
	var styleElements = document.getElementsByTagName("style");

	for(var i = 0; i < styleElements.length; i++) {
		var styleText = styleElements[i].firstChild.data;
		// this should be using match(/\b[\w-.]+(?=\s*\{)/g but ?= causes an
		// error in IE5, so we include the open brace and then strip it
		allStyleRules = styleText.match(/\b[\w-.]+(\s*\{)/g);
	}

    if (allStyleRules) {
        for(var i = 0; i < allStyleRules.length; i++) {
            // probably insufficient for people who like random gobs of
            // whitespace in their styles
            allStyleRules[i] = allStyleRules[i].substr(0, (allStyleRules[i].length - 2));
        }
    }
    ugly_selectorText_workaround_flag = true;
}

// setStyleByTag: given an element type, style property and
// value, and whether the property should override inline styles or
// just global stylesheet preferences, apply the style.
// args:
//  handle - a reference to the document element
//  e - element type or id
//  p - property
//  v - value
//  g - boolean 0: modify global only; 1: modify all elements in document
function setStyleByTag(e, p, v, g) {
	if(g) {
		var elements = visitorSellsISS.document.getElementsByTagName(e);
		for(var i = 0; i < elements.length; i++) {
			elements.item(i).style[p] = v;
		}//end for
	} else {
		var sheets = visitorSellsISS.document.styleSheets;
		if(sheets.length > 0) {
			for(var i = 0; i < sheets.length; i++) {
				var rules = sheets[i].cssRules;
				if(rules.length > 0) {
					for(var j = 0; j < rules.length; j++) {
						var s = rules.item[j].style;
						// selectorText broken in NS 6/Mozilla: see
						// http://bugzilla.mozilla.org/show_bug.cgi?id=51944
						ugly_selectorText_workaround();
						if(allStyleRules) {
							if(allStyleRules[j] == e) {
								s[p] = v;
							}
						} else {
							// use the native selectorText and style stuff
							if(((s[p] != "") && (s[p] != null)) &&
							(rules.item[j].selectorText == e)) {
								s[p] = v;
							}
						}
					}
				}
			}
		}
	}
}// end function setStyleByTag()

function popuponload() {

    //get the font size from main window
    var h3size = getComputedPropertyValue('h3','font-size');
    var psize = getComputedPropertyValue('p','font-size');
    var tdsize = getComputedPropertyValue('td','font-size');
    //set the font size on the popup window
	setStyleByTag('h3', 'fontSize', h3size, 1);
	setStyleByTag('p', 'fontSize', psize, 1);
    setStyleByTag('td', 'fontSize', tdsize, 1);
}

function popupWindow() {

    visitorSellsISS=window.open('/do/public/visitorSellsISS', 'visitorSellsISS', 'width=600, height=400, scrollbars=yes');
	visitorSellsISS.onload = popuponload;
}

function popupWindowCN() {
    visitorSellsCN=window.open('/do/public/sosCN', 'sosCN', 'width=600, height=400, scrollbars=yes');
	visitorSellsCN.onload = popuponload;
}
