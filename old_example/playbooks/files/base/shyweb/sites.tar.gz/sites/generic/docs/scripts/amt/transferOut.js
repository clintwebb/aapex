function disableTransferAtMarketValue() {
    try {
        document.TransferOutForm.transferAtMarketValue[0].checked = false;
        document.TransferOutForm.transferAtMarketValue[0].disabled = true;
        document.TransferOutForm.transferAtMarketValue[1].checked = true;
        document.TransferOutForm.transferAtMarketValue[1].disabled = true;
    } catch (err) {
    }
}


function enableTransferAtMarketValue() {
    try {
        document.TransferOutForm.transferAtMarketValue[0].disabled = false;
        document.TransferOutForm.transferAtMarketValue[1].disabled = false;
    } catch (err) {
    }
}


function transferAtMarketValueYN() {
    var returnVal = "N";
    try {
        if (document.TransferOutForm.transferAtMarketValue[0].checked) {
            returnVal = "Y";
        }
    } catch (err) {
    }
    return returnVal;
}


function disableFields() {
    //console.log("disableFields");
    if(document.TransferOutForm.changeInBO[0].checked) {
        disableTransferAtMarketValue();
    }
    disableTransferQty();

    addOrRemoveHistorical();
}


function disableReceivingHIN() {
    if(document.TransferOutForm.transferType.value == '007' ||
        document.TransferOutForm.transferType.value == '011' ||
        document.TransferOutForm.transferType.value == '251' ) {
        document.TransferOutForm.receivingHIN.disabled = true
    } else {
        document.TransferOutForm.receivingHIN.disabled = false;
    }
}


function collateHoldingDetails(){
    document.TransferOutForm.holdingDetails.value = "";

    for (var i = 0; i < document.forms.length; i++){
        if (document.forms[i].name == "HoldingForm") {
            if(parseInt(document.forms[i].transferQty.value) > parseInt(document.forms[i].registeredUnits.value)) {
                alert("Transfer quantity can not be more than registered units for security code " + document.forms[i].secCode.value);
                return false;
            }

            if (document.TransferOutForm.holdingDetails.value != "") {
                document.TransferOutForm.holdingDetails.value = document.TransferOutForm.holdingDetails.value + "+";
            }

            document.TransferOutForm.holdingDetails.value = document.TransferOutForm.holdingDetails.value
                + "SC="+ document.forms[i].secCode.value           + "|"
                + "AU="+ document.forms[i].availableUnits.value    + "|"
                + "RU="+ document.forms[i].registeredUnits.value   + "|"
                + "TQ="+ document.forms[i].transferQty.value       + "|"
                + "CD="+ document.forms[i].cgtDate.value           + "|"
                + "MV="+ document.forms[i].mktValue.value;
        }
    }
    document.TransferOutForm.submitAction.value="Submit";
    document.TransferOutForm.submit();
    return true;
}


function disableTransferQty() {
    disableReceivingHIN();
    var additionalRequestValue = document.getElementById("selectrequesttype").value;

    for (var i = 0; i < document.forms.length; i++){
        if (document.forms[i].name == "HoldingForm") {
            if(document.TransferOutForm.transferType.value == '251') {
                document.forms[i].transferQty.value = document.forms[i].registeredUnits.value;
                document.forms[i].transferQty.disabled = true;
            } else {
                document.forms[i].transferQty.disabled = false;
            }
            if(document.TransferOutForm.changeInBO[1].checked  && transferAtMarketValueYN() == "N") {
                document.forms[i].cgtDate.value = "";
                document.forms[i].cgtDate.disabled = true;
                document.forms[i].mktValue.value = "";
                document.forms[i].mktValue.disabled = true;
            }
            if (additionalRequestValue == "TNHP") {
                if (document.forms[i].name == "HoldingForm") {
                    document.forms[i].cgtDate.value = "";
                    document.forms[i].cgtDate.disabled = true;
                }
            }
        }
    }
}


function addTransferHistorical() {
    var additionalRequest = document.getElementById("selectrequesttype");
    if (additionalRequest.length == 3) {
        var xferHistorical = document.createElement("OPTION");
        xferHistorical.text = "Trf NCBO historical parcels";
        xferHistorical.value = "TNHP";
        additionalRequest.add(xferHistorical);
    }
}


function removeTransferHistorical() {
    var additionalRequest = document.getElementById("selectrequesttype");
    var i;
    for (i = 0; i < additionalRequest.length; i++) {
        if (additionalRequest.options[i].value == "TNHP") {
            additionalRequest.remove(i);
            i--;
        }
    }
}


function enableCBAndDateAndMktValue() {
    if(document.TransferOutForm.changeInBO[1].checked) {
        enableTransferAtMarketValue();
    } else {
        disableTransferAtMarketValue();
    }

    addOrRemoveHistorical();

    for (var i = 0; i < document.forms.length; i++){
        if (document.forms[i].name == "HoldingForm") {
            if(document.TransferOutForm.changeInBO[1].checked && transferAtMarketValueYN() == "N") {
                document.forms[i].cgtDate.value = "";
                document.forms[i].cgtDate.disabled = true;
                document.forms[i].mktValue.value = "";
                document.forms[i].mktValue.disabled = true;
            } else {
                document.forms[i].cgtDate.disabled = false;
                document.forms[i].mktValue.disabled = false;
            }
        }
    }
}


function enableDateAndMktValue() {
    addOrRemoveHistorical();

    for (var i = 0; i < document.forms.length; i++){
        if (document.forms[i].name == "HoldingForm") {
            if(transferAtMarketValueYN() == "N") {
                document.forms[i].cgtDate.value = "";
                document.forms[i].cgtDate.disabled = true;
                document.forms[i].mktValue.value = "";
                document.forms[i].mktValue.disabled = true;
            } else {
                document.forms[i].cgtDate.disabled = false;
                document.forms[i].mktValue.disabled = false;
            }
        }
    }
}


function checkChangeInBO() {
    if(document.TransferOutForm.changeInBO[1].checked && transferAtMarketValueYN() == "N") {
        alert("There is no change in Beneficial Ownership. You can not change this field.");
        document.TransferOutForm.currentBroker.focus();
    }
    return;
}


function enableBasedOnRequestType() {
    //If the user chooses the new requestType of "Transfer NCBO historical parcels" then disable the CGTDate (Marketvalue will already be enabled because changeInBO = N and transferAtMarketValue = Y)
    //If the user chooses anything else apart from the new requestType then call enableDateAndMktValue to enable/disable CGTDate and Marketvalue
    var additionalRequestValue = document.getElementById("selectrequesttype").value;
    if (additionalRequestValue == "TNHP") {
        for (var i = 0; i < document.forms.length; i++){
            if (document.forms[i].name == "HoldingForm") {
                document.forms[i].cgtDate.value = "";
                document.forms[i].cgtDate.disabled = true;
            }
        }
    } else {
        enableDateAndMktValue();
    }
}

function addOrRemoveHistorical() {
    //console.log(document.getElementById("selectrequesttype").length);

    if(document.TransferOutForm.changeInBO[1].checked && transferAtMarketValueYN() == "Y") {
        //console.log("adding");
        addTransferHistorical();
    } else {
        removeTransferHistorical();
        //console.log("removing");
    }
}