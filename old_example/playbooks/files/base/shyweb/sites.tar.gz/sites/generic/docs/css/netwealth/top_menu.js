<!--//--><![CDATA[//><!--
var TID = 0;
var t = false;
var subWidth = 108;

function findObjPos (id) {
	var obj = document.getElementById(id);
	var pos = new Array(0,0);

	while (obj) {
		pos[0] += obj.offsetLeft;
		pos[1] += obj.offsetTop;
		obj = obj.offsetParent;
	}
	return pos;
}

function showSub(subId, parentId, side, last) {
	var Y_OFFSET = 0;
	var ParentCoords = findObjPos(parentId);
    var newtop = ParentCoords[0];
    var newleft = ParentCoords[1] + subWidth;
	subObj = document.getElementById(subId);
	if (!subObj) return;
	if (!side) {
		if (last || parseInt(ParentCoords[0]) + subWidth >= document.body.scrollWidth)
			newleft = parseInt(ParentCoords[0]) + (document.getElementById(parentId).offsetWidth) - subWidth;
		else
			newleft = parseInt(ParentCoords[0]);
		newtop = parseInt(ParentCoords[1]) + (document.getElementById(parentId).offsetHeight) + Y_OFFSET;
	}
	else {
		if (last || parseInt(ParentCoords[0]) + (document.getElementById(parentId).offsetWidth) + subWidth >= document.body.scrollWidth)
			newleft = parseInt(ParentCoords[0]) - subWidth + 1;
		else
			newleft = parseInt(ParentCoords[0]) + (document.getElementById(parentId).offsetWidth) + 1;
		newtop = parseInt(ParentCoords[1]);
	}
    subObj.style.left = "" + newleft + "px";
    subObj.style.top  = "" + newtop  + "px";
	subObj.style.visibility = 'visible';
}

function showSub2(subId, parentId, side, last) {
	var X_OFFSET = -6;
	var Y_OFFSET = 0;
	var ParentCoords = findObjPos(parentId);
	subObj = document.getElementById(subId);
	if (!subObj) return;
	if (!side) {
		subObj.style.left = parseInt(ParentCoords[0]);
		subObj.style.top = parseInt(ParentCoords[1]) + (document.getElementById(parentId).offsetHeight) + Y_OFFSET;
	}
	else {
		subObj.style.left = parseInt(ParentCoords[0]) + (document.getElementById(parentId).offsetParent.offsetWidth) + X_OFFSET;
		subObj.style.top = parseInt(ParentCoords[1]);
	}
	subObj.style.visibility = 'visible';
}

function hideSub(id) {
	if (TID != 1)
	if (document.getElementById(id))
		document.getElementById(id).style.visibility = 'hidden';
}

function mouseOverSub(id) {
	TID = 1;
	document.getElementById(id).style.visibility = 'visible';
}

function mouseOutSub(id) {
	TID = 0;
	if (!t)
		document.getElementById(id).style.visibility = 'hidden';
}

function getObjXY(obj) {
  var left=0, top=0;
  while (obj!=null) {
   left+=obj.offsetLeft;
   top+=obj.offsetTop;
   obj=obj.offsetParent;
  }
  return {x:left,y:top};
 }

function showhidemenu(link) {
  linkObj = MM_findObj(document.getElementById(link));
  linkObj.style.visibility = "visible";


 }

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_showHideLayers() { //v3.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  objxy=getObjXY(document.getElementById(args[0]));
  for (i=1; i<(args.length-2); i+=3)
	if ((obj=MM_findObj(args[i]))!=null) {
     v=args[i+2];
    if (obj.style) {
	 obj=obj.style; v=(v=='show')?'visible':(v='hide')?'hidden':v;
	 }
	 obj.left=objxy.x + 10;
	 obj.top=objxy.y;
    obj.visibility=v;
	}
}

function topmenu_showHideLayers() { //v3.0
    var i,p,v,obj,args=topmenu_showHideLayers.arguments;
    objxy=getObjXY(document.getElementById(args[0]));
    for (i=1; i<(args.length-2); i+=3) {
        if ((obj=MM_findObj(args[i]))!=null) {
            v=args[i+2];
            if (obj.style) {obj=obj.style; v=(v=='show')?'visible':(v='hide')?'hidden':v;}
            obj.left=objxy.x+5;
            obj.top=objxy.y+2;
            obj.visibility=v;
        }
    }
}

var delayhide;
var delayTrue;
function delayshowrollover(rolloverContainer,rolloverText){
    var func = "MM_showHideLayers('" + rolloverContainer + "','" + rolloverText + "',''," + "'show')";
    //alert(func);
    delayhide=setTimeout(func,150);
    delayTrue=true;
}

function cleardelay(){
    if (delayTrue) {
        clearTimeout(delayhide);
        delayTrue=false;
    }
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function privacy_popup(pagename,swidth,sheight,scroll) {
		y_pos = (screen.height-sheight)/2;	// make the window pop up
		x_pos = (screen.width-swidth)/2;	// in the middle of the screen
		app1="toolbar=no";
		app2="width="+swidth;
		app3="height="+sheight;
		app4="menubar=no";
		app5="resizable=no";
		app6="scrollbars="+scroll;
		app7="left="+x_pos;
		app8="top="+y_pos;
		app=app1+","+app2+","+app3+","+app4+","+app5+","+app6+","+app7+","+app8;
		window.open(pagename,"temp",app)
	}

function getPos(e) {
  var top = 0, left = 0;
  if (!e) { e = window.event; }
  var myTarget = e.currentTarget;
  if (!myTarget) {
   myTarget = e.srcElement;
  }
  else if (myTarget == "undefined") {
   myTarget = e.srcElement;
  }
  while(myTarget!= document.body) {
     top += myTarget.offsetTop;
     left += myTarget.offsetLeft;
     myTarget = myTarget.offsetParent;
  }

  alert("left: " + left +
     "\ntop: " + top);

}

function setloc (e){

x_pos = (screen.width - 300);
alert("left: " + x_pos);
window.location = 'home.asp?w=' + x_pos;
}

function hideCombo() {

}

function showCombo() {

}
//--><!]]>
