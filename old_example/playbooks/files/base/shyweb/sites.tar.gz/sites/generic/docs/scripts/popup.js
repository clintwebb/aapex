function newPDFWindow(url) {
  window.open(url, 'PDFWindow', 'width=800,height=600,scrollbars,resizable,status,menubar,left=120,top=20,');
}

function newWindow(url, winName) {
  window.open(url, winName, 'width=650,height=420,scrollbars,resizable,status,menubar,left=120,top=20,');
}

