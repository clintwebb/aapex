<!--//--><![CDATA[//><!--

//Determines whether OS is Mac or PC and call different css to fix iframes for dropdowns
var sStyleFile;
if ( navigator.appVersion.indexOf("Mac")!=-1 ) {
    sStyleFile = "covermenu_formac.css"
}
else {
    sStyleFile = "covermenu.css"
}
document.writeln('<link rel="stylesheet" type="text/css" href="/css/' + sStyleFile + '">');

// IE fixes have been moved into netwealth-ie-fixes.jsp .
// Dummy statement below to keep the javascript parser happy.
var iVersion;
var sBrowserName = navigator.userAgent.toLowerCase();
//--><!]]>
