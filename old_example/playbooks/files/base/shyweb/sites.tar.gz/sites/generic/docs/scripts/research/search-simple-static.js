/* Index of the current user query being edited */
currentUserQueryIndex = 0;

/**
 * seperator between the parameters
 * constant used for parsing and storing in uerqueries elements
 */
separator = "+";

/* Array user to store the elements after parsing */
strElements = new Array(8);

/* Array user to store the elements after parsing */
nbOfQueries = 20;

/**
 * initialises the page , that is load the values in the
 * querylist and
 *
 * @param formEngine form to be submitted to the Query Engine
 * @param formUser   form filled out by the user
 */
function initialise(formEngine, formUser) {

  formUser.Category.selectedIndex = [-1];
  formUser.Field.length = 1;
  updateQueryList(formEngine, formUser);
  formUser.Category.focus;
}

/**
 * resets the user entry form to starting values
 *
 * @param formUser   form filled out by the user
 */

function resetFormUser(formUser) {
  formUser.Category.selectedIndex = [-1];
  formUser.Field.length = 1;
  formUser.Field.options[0].text = ' --- SELECT A CATEGORY --- ';
  formUser.Criterion.options[formUser.Criterion.options.length - 1].selected = true;
  formUser.UserValue.value = '';
  formUser.SelectValue.length = 0;
  formUser.ValueType[1].checked=false;
  formUser.ValueType[0].checked=false;
}


/**
 * Resets the query form and query values
 *
 * @param form1
 * @param form2
*/
function resetList(formEngine, formUser) {
   for (i=0; i< nbOfQueries; i++) formEngine.userqueries[i].value="";
    updateQueryList(formEngine, formUser);
}


/**
 * Stores values from query boxes into queryvalue
 *
 * @formIn  The form from which the data comes
 * @formOut The destination form.
 */
function storeQuery(formIn, formOut) {

  var stored = false;
  var selectedCriterion="";
  var selectedUserQuery="";
  // Category
  var itemCategory = formIn.Category.selectedIndex;
  if (itemCategory == -1) alert('Please select a valid category.');
  else {
    selectedUserQuery = formIn.Category.options[itemCategory].text;
 // Field
    var itemField = formIn.Field.selectedIndex;
    if (itemField == -1) alert('Please select a valid field.');
    else {
      selectedUserQuery += separator+formIn.Field.options[itemField].text;
 // Criterion
      var itemCriterion = formIn.Criterion.selectedIndex;
      if (itemCriterion == -1) alert('Please select a valid criterion.');
      else {
        selectedCriterion = translateCriterionInOut(formIn.Criterion.options[itemCriterion].text);
        selectedUserQuery += separator+selectedCriterion;
 // ValueType novalue
        if ((selectedCriterion == "Display only")
         || (selectedCriterion == "Rank highest")
         || (selectedCriterion == "Rank lowest")) {
          selectedUserQuery += separator+"novalue";
          stored = true;
        } else {
 // ValueType user
          if (formIn.ValueType[0].checked) {
            var selectedValue = formIn.UserValue.value;
            if (selectedValue == "") alert('Please provide a valid value.');
            else if (isNaN(selectedValue)) {
              var msg = "The format of the value you have entered is incorrect. Please enter the full number.\n"
              msg += "For example 10 million should be entered as 10000000 and 10% should be entered as 0.1"
              alert(msg);
            } else {
              selectedUserQuery += separator+"user"+separator+selectedValue;
              stored = true;
            }
 // ValueType predefined
          } else if (formIn.ValueType[1].checked) {
            var itemValue = formIn.SelectValue.selectedIndex;
            if (itemValue == -1) alert('Please select a value.');
            else {
              selectedUserQuery += separator+"predefined"+separator+formIn.SelectValue.options[itemValue].text;
              stored = true;
            }
          } else if (formIn.ValueType[2] != null && formIn.ValueType[2].checked) {
            if ((formIn.Factor.value == "") || isNaN(formIn.Factor.value)) formIn.Factor.value = "1.0";
            selectedUserQuery += separator+"comparison"+separator+formIn.Factor.value;
            var itemCatC = formIn.CategoryC.selectedIndex;
            if (itemCatC == -1) alert('Please select a valid category for comparison.');
            else {
              selectedUserQuery += separator+formIn.CategoryC.options[itemCatC].text;
              var itemFieldC = formIn.FieldC.selectedIndex;
              if (itemFieldC == -1) alert('Please select a valid category for comparison.');
              else if ((itemCatC == itemCategory) && (itemFieldC == itemField))
                alert('You cannot compare a Category/Field against itself.');
              else {
                selectedUserQuery += separator+formIn.FieldC.options[itemFieldC].text;
                stored = true;
              }
            }
          } else alert("Please select a value type.");
        }
      }
    }
  }
  if (stored == true) formOut.userquery.value=selectedUserQuery;
  return stored;
}

/**
 * Runs the query (submits it)
 *
 * @param formEngine the form to be submitted to the Query Engine
 */
function runQuery(formIn, formOut) {
    if (storeQuery(formIn, formOut)) {
	  //formOut.action="/do/secure/searchTool";
      formOut.submit();
    }
}

/**
 * Runs the query for the premium user
 *
 * @param formOut the form to be submitted to the Query Engine
 */
function runQueries(formOut) {
	  formOut.action="/do/secure/searchToolSelector";
	  formOut.submitAction.value="Run";
      formOut.submit();
}

/**
 * Stores the current user query, that is all the elements selected by the
 * User on the displayed form and saves the data in the form to be submitted
 * to the Query Engine.
 * Changes are then reflected on the Query List.
 *
 * @param formIn    form filled out by the user and displayed on the screen
 * @param formOut   form to be submitted to the Query Engine
 */
function addQuery(formIn, formOut) {
    if (formOut.userqueries[nbOfQueries-1].value == ""){
        if (storeQuery(formIn, formOut)) {
            formOut.userqueries[currentUserQueryIndex].value = formOut.userquery.value;
            updateQueryList(formOut,formIn);
        }
    } else {
        alert('You have exceeded the number of allowable queries. Please remove one or more of the queries from the query list if you wish to add another one.');
    }
    currentUserQueryIndex=findNextAvailableIndex(formOut);
}

/**
 * Update the value input/list and criterion depending on the field selected
 *
 * form: the form which contains the 'Criterion', 'Field',
 */
function updateValue(form) {
   form.UserValue.value = "";
   updateCriterion(form);
   checkValueList(form);
   checkValueType(form);
}

/**
 * Saves the query.
 * Unless the user press cancel, he is prompted until he enters a valid
 * name for the query (between 1 and 15 characters) and the form is
 * submitted.
 *
 * @param formEngine The form to be saved.
 */
function saveQuery(formEngine, action) {
 // var namesaved = prompt("Enter query name to be saved as: (max 15 char)", formEngine.querySetName.value);
 // while ((namesaved == "") && (namesaved != null))
 //   namesaved = prompt("Enter query name to be saved as: (min 1 char)", "Saved");
 // while ((namesaved.length > 15) && (namesaved != null))
//    namesaved = prompt("Enter query name to be saved as: (max 15 char)", "Saved");
 // if (namesaved != null) {
   // window.status="Saving \'"+namesaved+"\' to saved queries, please wait...";
   // formEngine.querySetName.value = namesaved;
    formEngine.action="/do/secure/searchToolSelector";
   formEngine.submitAction.value=action;
    formEngine.submit();
  //  window.status="\'"+namesaved+"\' saved.";
 // }
}

/**
 * Clears the selected field in the form to be submitted to the Query Engine.
 * The changes are then reflected in the Query List using the updateQueryList
 * function.
 *
 * @param formEngine form to be submitted to the Query Engine
 * @param formList   form which contains the list
 */
function clearField(formEngine,formList) {
  clearIndex = formList.QueryList.selectedIndex;
  if (clearIndex == -1) {
    alert('Please select a valid query entry.');
  } else if (clearIndex < findNextAvailableIndex(formEngine) ){
    for (i = clearIndex; i < nbOfQueries-1; i++){
      formEngine.userqueries[i].value = formEngine.userqueries[i+1].value;
    }
    formEngine.userqueries[nbOfQueries-1].value="";
    updateQueryList(formEngine,formList);
  }
}

/**
 * opens a new window with a description of each field depending on its
 * glossary ID
 *
 * @param glossaryId The unique identifier of a term in the glossary
 */
function glossaryTerm(glossaryId){
  if (glossaryId == null) alert("No glossary for this field")
  else {
    var filename = "/glossary/glossary" + glossaryId + ".html";
    window.open(filename, "Glossary", "width=275,height=300,resizable=no,scrollbars=yes");
  }
}

/**
 * finds the next available index of userquery object in the form
 *
 * @param form The form
 */
function findNextAvailableIndex (Form){
    var index=0;
  while ((index < nbOfQueries) && (Form.userqueries[index].value != "")) index++;
    return index;
}

/**
 * updates the querylist by parsing the userqueries in the first form
 * conditions:
 * - formEngine contains several input called 'userquery'
 * - formList contains a QueryList option list
 *
 * @param formEngine  The form which contains the user query
 * @param formList    The form which contains the queryList select box
 */
function updateQueryList(formEngine, formList) {
    for (i = 0; i < nbOfQueries; i++) {
        parse(formEngine.userqueries[i].value);
        if (strElements[0] != "") {
            var queryDisplay = strElements[1] + " " + strElements[2];
            if ((strElements[3] == "user") || (strElements[3] == "predefined"))
                queryDisplay += " " + strElements[4];
            else if (strElements[3] == "comparison")
                queryDisplay += " " + strElements[4] + " x " + strElements[6];

            //  formList.QueryList.length = formList.QueryList.length + 1;
            //    var no = new Option();
            //  no.text = queryDisplay;
            //  formList.QueryList.options[i] = no;
            formList.QueryList.options[i].text = queryDisplay;
        } else formList.QueryList.options[i].text = "";
    }
    currentUserQueryIndex = findNextAvailableIndex(formEngine);
}

/**
 * parse a string and stored elements separated by "separtor"
 * in an array. In this version, the length of the array is 8.
 *
 * @param unparsedString  The string to parse
 * @return  An array of elements
 */
function parse (unparsedString) {
  strElements = new Array(8);
  var tmp = unparsedString;
  var i=0;
  while ( tmp.indexOf(separator)!= -1 ) {
    strElements[i] = tmp.substring(0,tmp.indexOf(separator));
    tmp = tmp.substring(tmp.indexOf(separator)+1,tmp.length);
    i++
  }
  strElements[i] = tmp;
}

/**
 * Displays all the values of an array in an alert window
 *
 * @param Array the array which values have to be displayed
 */
function alertArray(strArray) {
  var arrayValues="";
  for (i=0;i< strArray.length; i++) arrayValues += i+" : "+strArray[i]+"\n";
  alert(arrayValues);
}

/**
 * Translate the Criterion value from the input form into
 * a correct Criterion for the output form.
 *
 * val: the value to be translated
 */
function translateCriterionInOut(val) {
  if (val == "Greater than") return ">";
  else if (val == "Less than") return "<";
  else if (val == "Equal to") return "=";
  else return val;
}

/**
 * Translate the Criterion value from the input form into
 * a correct Criterion for the output form.
 *
 * val: the value to be translated
 */
function translateCriterionOutIn(val) {
  if ((val == ">") || (val == "&gt;")) return "Greater than";
  else if ((val == "<") || (val == "&lt;")) return "Less than";
  else if (val == "=") return "Equal to";
  else return val;
}

/**
 * clears the user value and unchecks the corresponding ValueType
 *
 * @param formUser The form which contains these values
 */
function clearUserValue(formUser) {
  formUser.ValueType[0].checked=false;
  formUser.UserValue.value="";
}

/**
 * clears the user value and unchecks the corresponding ValueType
 *
 * @param formUser The form which contains these values
 */
function clearPredefinedValue(formUser) {
  formUser.ValueType[1].checked=false;
  formUser.SelectValue.selectedIndex=[-1];
}

/**
 * clears the values associated to a comparison with another
 * category/field, unchecks the corresponding ValueType
 *
 * @param formUser The form which contains these values
 */
function clearComparison(formUser) {
  //formUser.ValueType[2].checked=false;
  //formUser.Factor.value="1.0";
  //formUser.CategoryC.selectedIndex=[-1];
  //formUser.FieldC.selectedIndex=[-1];
  //formUser.FieldC.length=0;
}
