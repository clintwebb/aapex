<!--  // HIDE SCRIPT
function winClose() {
    window.close();
}

function showIndex() {
    location="help";
}

function goBack() {
    history.back();
}
// END HIDE -->