        function disableFields() {
           updateFields();
        }

        function updateFields() {

            var transferType = document.TransferInForm.transferType.options[document.TransferInForm.transferType.selectedIndex].value;

            if(transferType == '005') {

               updateFor005TransferType();

            } else if(transferType == '245') {

               updateFor245TransferType();

            } else if(transferType == '015' || transferType == '017') {

               updateFor015OR017TransferType();

            } else if(transferType == 'BW1' || transferType == 'BW2') {

               updateForBW1BW2TransferType();

            } else {

               clearAll();
            }
        }

        function updateFor005TransferType() {

            document.TransferInForm.srn.disabled = true;
            enableField(document.TransferInForm.receivingHIN);
            enableField(document.TransferInForm.currentBroker);
            enableField(document.TransferInForm.reference);
        }


        function updateFor245TransferType() {

            document.TransferInForm.srn.disabled = true;
            document.TransferInForm.reference.disabled = true;
            enableField(document.TransferInForm.receivingHIN);
            enableField(document.TransferInForm.currentBroker);
        }


        function updateFor015OR017TransferType() {

            document.TransferInForm.currentBroker.disabled = true;
            document.TransferInForm.reference.disabled = true;
            enableField(document.TransferInForm.receivingHIN);
            enableField(document.TransferInForm.srn);
        }

        function updateForBW1BW2TransferType() {

            document.TransferInForm.srn.disabled = true;
            document.TransferInForm.reference.disabled = true;
            document.TransferInForm.receivingHIN.disabled = true;
            document.TransferInForm.currentBroker.disabled = true;
        }

        function clearAll() {
            enableField(document.TransferInForm.receivingHIN);
            enableField(document.TransferInForm.srn);
            enableField(document.TransferInForm.currentBroker);
            enableField(document.TransferInForm.reference);
        }

        function enableField(field) {
            field.disabled = false;
        }

        function disableField(field) {
            field.value='';
            field.disabled = true;
        }