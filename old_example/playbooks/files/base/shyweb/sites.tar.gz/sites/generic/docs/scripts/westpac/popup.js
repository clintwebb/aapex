function newPDFWindow(url) {
  window.open(url, 'PDFWindow', 'width=800,height=600,scrollbars,resizable,status,menubar,left=120,top=20,');
}

function newWindow(url, winName) {
  window.open(url, winName, 'width=650,height=420,scrollbars,resizable,status,menubar,left=120,top=20,');
}

function showFlyoutChild(parent, childId) {
    if ('undefined' != typeof document.getElementById) {
        var childObject = document.getElementById(childId);
        childObject.style.left = (findPosX(parent) + 130) + 'px';
        childObject.style.top = findPosY(parent) + 'px';
        childObject.style.visibility = 'visible';

        if (isIE56()) {
            // Place an iframe directly under the flyout so that in IE5/6, select boxes do not show through.
            var iframe = document.getElementById('iframe');
            iframe.style.width = childObject.offsetWidth;
            iframe.style.height = childObject.offsetHeight;
            iframe.style.left = (findPosX(childObject)) + 'px';
            iframe.style.top = findPosY(childObject) + 'px';
            iframe.style.visibility = 'visible';
        }
    }
}

function hideFlyoutChild(parent, childId) {
        if ('undefined' != typeof document.getElementById) {
            var childObject = document.getElementById(childId);
            childObject.style.visibility = 'hidden';

            if (isIE56()) {
                var iframe = document.getElementById('iframe');
                iframe.style.visibility = 'hidden';
                iframe.style.width = '1px';
                iframe.style.height = '1px';
                iframe.style.left = '1px';
                iframe.style.top = '1px';
            }
        }
}

function showFlyout(me) {
    me.style.visibility = 'visible';

    if (isIE56()) {
        var iframe = document.getElementById('iframe');
        iframe.style.width = me.offsetWidth;
        iframe.style.height = me.offsetHeight;
        iframe.style.left = (findPosX(me)) + 'px';
        iframe.style.top = findPosY(me) + 'px';
        iframe.style.visibility = 'visible';
    }
}

function hideFlyout(me) {
    me.style.visibility = 'hidden';

    if (isIE56()) {
        var iframe = document.getElementById('iframe');
        iframe.style.visibility = 'hidden';
        iframe.style.width = '1px';
        iframe.style.height = '1px';
        iframe.style.left = '1px';
        iframe.style.top = '1px';
    }
}

function findPosX(obj) {
    var curleft = 0;
    if (obj.offsetParent) {
        while (obj.offsetParent) {
            curleft += obj.offsetLeft
            obj = obj.offsetParent;
        }
    } else if (obj.x) {
        curleft += obj.x;
    }
    return curleft;
}

function findPosY(obj) {
    var curtop = 0;
    if (obj.offsetParent) {
        while (obj.offsetParent) {
            curtop += obj.offsetTop
            obj = obj.offsetParent;
        }
    } else if (obj.y) {
        curtop += obj.y;
    }
    return curtop;
}

function isIE56() {
    // Determine if browser is Internet Explorer
    var sBrowserName = navigator.userAgent.toLowerCase();
    if (sBrowserName.indexOf('msie') != -1) {

        var iVersion = parseFloat(sBrowserName.substring(sBrowserName.indexOf('msie ') + 5));

        // Determine if the version of Internet Explorer is version 5 / 6.
        if (parseInt(iVersion) >= 5 && parseInt(iVersion) < 7) {
            return true;
        }
    }
    return false;
}

