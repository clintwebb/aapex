        function disableFields() {

            var serviceType = document.MaintainClientForm.serviceType.options[document.MaintainClientForm.serviceType.selectedIndex].value;

            // when retrieving details ensure that the reason codes are enabled, otherwise they are to be disabled
           //alert(document.MaintainClientForm.clientRetrieved.value);
            if (document.MaintainClientForm.clientRetrieved.value == "N"){
             //alert("condition met, N");
             disableField(document.MaintainClientForm.reasonCode1);
             disableField(document.MaintainClientForm.reasonCode2);
            }


            if(serviceType == 'BTML' || serviceType == 'BTGIP') {

               disableForMLGIPServiceType(serviceType);

            } else if(serviceType == 'BTAPP' || serviceType == 'BTPSP' || serviceType == 'BTCS' || serviceType == 'BTCM' || serviceType == 'BTTAP') {

               disableForAPPPSPCSCMTAPServiceType(serviceType);

            } else if(serviceType == 'BTBW') {

               disableForBWServiceType(serviceType);

            } else {
               clearAll();
            }

           var country = document.MaintainClientForm.country.options[document.MaintainClientForm.country.selectedIndex].value;

           if(country != 'AUS') {
              document.MaintainClientForm.state.selectedIndex = 0;
              disableField(document.MaintainClientForm.suburbLocality);
              disableField(document.MaintainClientForm.state);
              disableField(document.MaintainClientForm.postalCode);
           }
        }

        function updateFields() {

            var serviceType = document.MaintainClientForm.serviceType.options[document.MaintainClientForm.serviceType.selectedIndex].value;

            if(serviceType == 'BTML' || serviceType == 'BTGIP') {

               updateForMLGIPServiceType(serviceType);

            } else if(serviceType == 'BTAPP' || serviceType == 'BTPSP' || serviceType == 'BTCS' || serviceType == 'BTCM' || serviceType == 'BTTAP') {

               updateForAPPPSPCSCMTAPServiceType(serviceType);

            } else if(serviceType == 'BTBW') {

               updateForBWServiceType(serviceType);

            } else {
               clearAll();
            }

            var country = document.MaintainClientForm.country.options[document.MaintainClientForm.country.selectedIndex].value;

            if(country != 'AUS') {
              document.MaintainClientForm.state.selectedIndex = 0;
              disableField(document.MaintainClientForm.suburbLocality);
              disableField(document.MaintainClientForm.state);
              disableField(document.MaintainClientForm.postalCode);
           }

        }

        function disableForMLGIPServiceType(serviceType) {
            var clientType = document.MaintainClientForm.clientType.options[document.MaintainClientForm.clientType.selectedIndex].value;

            disableField(document.MaintainClientForm.receivingHIN);
            disableField(document.MaintainClientForm.bankAccountNumber);

            if(serviceType == 'BTGIP') {
               if(clientType == 'I' || clientType == 'J' || clientType == 'C') {
                   emptyField(document.MaintainClientForm.accountDesignation);
                   disableField(document.MaintainClientForm.accountDesignation);
                }
            }
        }

        function updateForMLGIPServiceType(serviceType) {

            enableExtraRequest();

            if(document.MaintainClientForm.countrySave.value != 'NULL') {
              document.MaintainClientForm.accountName.value = document.MaintainClientForm.accountNameSave.value;
              document.MaintainClientForm.accountName.disabled = false;
              //document.MaintainClientForm.accountDesignation.value = document.MaintainClientForm.accountDesignationSave.value;
              document.MaintainClientForm.accountDesignation.disabled = false;
              document.MaintainClientForm.addressLine1.value = document.MaintainClientForm.addressLine1Save.value;
              document.MaintainClientForm.addressLine1.disabled = false;
              document.MaintainClientForm.addressLine2.value = document.MaintainClientForm.addressLine2Save.value;
              document.MaintainClientForm.addressLine2.disabled = false;
              document.MaintainClientForm.addressLine3.value = document.MaintainClientForm.addressLine3Save.value;
              document.MaintainClientForm.addressLine3.disabled = false;
              document.MaintainClientForm.suburbLocality.value = document.MaintainClientForm.suburbLocalitySave.value;
              document.MaintainClientForm.suburbLocality.disabled = false;
              document.MaintainClientForm.state.value = document.MaintainClientForm.stateSave.value;
              document.MaintainClientForm.state.disabled = false;
              document.MaintainClientForm.postalCode.value = document.MaintainClientForm.postalCodeSave.value;
              document.MaintainClientForm.postalCode.disabled = false;
              document.MaintainClientForm.country.value = document.MaintainClientForm.countrySave.value;
              document.MaintainClientForm.country.disabled = false;
            } else {
              enableAddress();
              enableField(document.MaintainClientForm.accountName);
              emptyField(document.MaintainClientForm.accountName);
            }


            if(document.MaintainClientForm.operationType.value == 'create') {
              enableAddress();
              enableField(document.MaintainClientForm.accountName);
              emptyField(document.MaintainClientForm.accountName);
            }

            emptyField(document.MaintainClientForm.receivingHIN);
            emptyField(document.MaintainClientForm.bankAccountNumber);


            if(serviceType == 'BTML') {
                enableField( document.MaintainClientForm.accountDesignation);
            }
            var clientType = document.MaintainClientForm.clientType.options[document.MaintainClientForm.clientType.selectedIndex].value;


            disableField(document.MaintainClientForm.receivingHIN);
            disableField(document.MaintainClientForm.bankAccountNumber);


            if(serviceType == 'BTGIP') {
               if(clientType == 'I' || clientType == 'J' || clientType == 'C') {
                   emptyField(document.MaintainClientForm.accountDesignation);
                   disableField(document.MaintainClientForm.accountDesignation);
               } else {
                   if(document.MaintainClientForm.operationType.value == 'create') {
                       emptyField(document.MaintainClientForm.accountDesignation);
                   }
               }
            }

        }

        function disableForBWServiceType(serviceType) {
            emptyField(document.MaintainClientForm.bankAccountNumber);
            disableField(document.MaintainClientForm.bankAccountNumber);
        }

        function updateForBWServiceType(serviceType) {
            document.MaintainClientForm.requestType.selectedIndex = 0;
            enableField(document.MaintainClientForm.receivingHIN);
            emptyField(document.MaintainClientForm.receivingHIN);
            enableField(document.MaintainClientForm.accountName);
            emptyField(document.MaintainClientForm.accountName);
            enableAddress();
            disableForBWServiceType(serviceType);
        }

        function disableForAPPPSPCSCMTAPServiceType(serviceType) {

            defaultAddress(serviceType);
            emptyField(document.MaintainClientForm.receivingHIN);
            disableField(document.MaintainClientForm.receivingHIN);
            document.MaintainClientForm.accountName.value = 'BT PORTFOLIO SERVICES LIMITED';
            disableField(document.MaintainClientForm.accountName);
        }

        function updateForAPPPSPCSCMTAPServiceType(serviceType) {

            enableExtraRequest();
            enableField(document.MaintainClientForm.bankAccountNumber);
            emptyField(document.MaintainClientForm.bankAccountNumber);
            enableField( document.MaintainClientForm.accountDesignation);
            disableForAPPPSPCSCMTAPServiceType(serviceType);
        }

        function enableExtraRequest() {

            document.MaintainClientForm.requestType.disabled = false;
            document.MaintainClientForm.requestType.selectedIndex = 0;
        }

        function validateExtraRequest(requestTypeSelect) {

            var serviceName = document.MaintainClientForm.serviceType.options[document.MaintainClientForm.serviceType.selectedIndex].value;
            var requestType = requestTypeSelect.options[requestTypeSelect.selectedIndex].value;
            var operationType = document.MaintainClientForm.operationType.value;

            if(serviceName == 'NULL') {
              alert('Please select a valid service type.');
              requestTypeSelect.selectedIndex = 0;
              return;
           }

            if(serviceName == 'BTBW') {
               if(requestType == 'NHIN' || requestType == 'CACH') {
                  requestTypeSelect.selectedIndex = 0;
                  alert('You can not select this request type for selected service type.');
                  return;
               }
            }

            if(operationType == 'create') {
               if(requestType == 'CACT' || requestType == 'CACH') {
                  requestTypeSelect.selectedIndex = 0;
                  alert('You can not select this request type for new investor accounts.');
                  return;
               }
            } else {
               if(serviceName == 'BTAPP' || serviceName == 'BTPSP' || serviceName == 'BTTAP') {
                  if(requestType == 'NHIN') {
                     requestTypeSelect.selectedIndex = 0;
                     alert('You can not select this request type for selected service type.');
                     return;
                  }
               }
            }
        }

        function clearAll() {
           enableAddress();
           enableField(document.MaintainClientForm.accountName);
           emptyField(document.MaintainClientForm.accountName);
           enableField(document.MaintainClientForm.bankAccountNumber);
           emptyField(document.MaintainClientForm.bankAccountNumber);
           enableField(document.MaintainClientForm.accountDesignation);
           emptyField(document.MaintainClientForm.accountDesignation);
           enableField(document.MaintainClientForm.receivingHIN);
           emptyField(document.MaintainClientForm.receivingHIN);
           enableField(document.MaintainClientForm.adviserID);
           emptyField(document.MaintainClientForm.adviserID);
           enableField(document.MaintainClientForm.clientType);
           emptyField(document.MaintainClientForm.clientType);
           document.MaintainClientForm.clientType.selectedIndex = 0;
           enableField(document.MaintainClientForm.requestType);
           emptyField(document.MaintainClientForm.requestType);
           document.MaintainClientForm.requestType.selectedIndex = 0;
        }

        function defaultAddress(serviceType) {

            enableAddress();
            if(serviceType == 'BTCS' || serviceType == 'BTCM') {
               document.MaintainClientForm.addressLine1.value = 'PO BOX 8499';
              } else {
               document.MaintainClientForm.addressLine1.value = 'PO BOX 8550';
              }

            disableField(document.MaintainClientForm.addressLine1);
            document.MaintainClientForm.addressLine2.value = '';
            disableField(document.MaintainClientForm.addressLine2);
            document.MaintainClientForm.suburbLocality.value = 'PERTH BC';
            disableField(document.MaintainClientForm.addressLine3);
            disableField(document.MaintainClientForm.suburbLocality);
            document.MaintainClientForm.state.selectedIndex = 5;
            disableField(document.MaintainClientForm.state);
            document.MaintainClientForm.postalCode.value = '6849';
            disableField(document.MaintainClientForm.postalCode);
            document.MaintainClientForm.country.selectedIndex = '0';
            disableField(document.MaintainClientForm.country);
        }

        function enableAddress() {
            enableField(document.MaintainClientForm.addressLine1);
            emptyField(document.MaintainClientForm.addressLine1);
            enableField(document.MaintainClientForm.addressLine2);
            emptyField(document.MaintainClientForm.addressLine2);
            enableField(document.MaintainClientForm.addressLine3);
            emptyField(document.MaintainClientForm.addressLine3);
            enableField(document.MaintainClientForm.suburbLocality);
            emptyField(document.MaintainClientForm.suburbLocality);
            enableField(document.MaintainClientForm.postalCode);
            emptyField(document.MaintainClientForm.postalCode);
            enableField(document.MaintainClientForm.state);
            emptyField(document.MaintainClientForm.state);
            enableField(document.MaintainClientForm.country);
            emptyField(document.MaintainClientForm.country);
            document.MaintainClientForm.country.selectedIndex = 0;
            document.MaintainClientForm.state.selectedIndex = 0;
        }

        function enableField(field) {
            field.disabled = false;
        }

        function disableField(field) {
            field.disabled = true;
        }

        function emptyField(field) {
            field.value='';
        }

        function checkState(countrySelect) {

           var country = countrySelect.options[countrySelect.selectedIndex].value;

           if(country != 'AUS') {
              document.MaintainClientForm.state.selectedIndex = 0;
              emptyField(document.MaintainClientForm.suburbLocality);
              disableField(document.MaintainClientForm.suburbLocality);
              disableField(document.MaintainClientForm.state);
              emptyField(document.MaintainClientForm.postalCode);
              disableField(document.MaintainClientForm.postalCode);
           } else {
              document.MaintainClientForm.suburbLocality.disabled = false;
              document.MaintainClientForm.state.disabled = false;
              document.MaintainClientForm.state.selectedIndex = 0;
              document.MaintainClientForm.postalCode.disabled = false;
              emptyField(document.MaintainClientForm.postalCode);
           }
        }


        function checkADBwGIPAccount(accountDesi) {

           var serviceName = document.MaintainClientForm.serviceType.options[document.MaintainClientForm.serviceType.selectedIndex].value;
           var clientType = document.MaintainClientForm.clientType.options[document.MaintainClientForm.clientType.selectedIndex].value;

           if(serviceName == 'BTML') {

              if(clientType == 'NULL') {
                 alert('Please select valid client type.');
                 document.MaintainClientForm.adviserID.focus();
              } else {
                  if(clientType == 'I' || clientType == 'J') {
                     disableField(accountDesi);
                     document.MaintainClientForm.adviserID.focus();
                  } else {
                     accountDesi.disabled = false;
                  }
              }
           }
           return;
        }

        function replaceAD() {

            var serviceTypeDesiGIP = 'A/C>';
            var serviceTypeDesiPSP = 'A/C>';
            var serviceTypeDesiCS = 'A/C>';
            var serviceTypeDesiML = 'BTML A/C>';
            var serviceTypeDesiCM = 'BTML A/C>';
            var serviceTypeDesiAPP = 'APP A/C>';
            var serviceTypeDesiTAP = 'TAP A/C>';

            var serviceTypeDesiOLD = null;
            var serviceTypeDesiNEW = null;

            if (document.MaintainClientForm.serviceTypeSave.value == 'BTGIP') serviceTypeDesiOLD = serviceTypeDesiGIP;
            if (document.MaintainClientForm.serviceTypeSave.value == 'BTPSP') serviceTypeDesiOLD = serviceTypeDesiPSP;
            if (document.MaintainClientForm.serviceTypeSave.value == 'BTCS') serviceTypeDesiOLD = serviceTypeDesiCS;
            if (document.MaintainClientForm.serviceTypeSave.value == 'BTML') serviceTypeDesiOLD = serviceTypeDesiML;
            if (document.MaintainClientForm.serviceTypeSave.value == 'BTCM') serviceTypeDesiOLD = serviceTypeDesiCM;
            if (document.MaintainClientForm.serviceTypeSave.value == 'BTAPP') serviceTypeDesiOLD = serviceTypeDesiAPP;
            if (document.MaintainClientForm.serviceTypeSave.value == 'BTTAP') serviceTypeDesiOLD = serviceTypeDesiTAP;

            if (document.MaintainClientForm.serviceType.value == 'BTGIP') serviceTypeDesiNEW = serviceTypeDesiGIP;
            if (document.MaintainClientForm.serviceType.value == 'BTPSP') serviceTypeDesiNEW = serviceTypeDesiPSP;
            if (document.MaintainClientForm.serviceType.value == 'BTCS') serviceTypeDesiNEW = serviceTypeDesiCS;
            if (document.MaintainClientForm.serviceType.value == 'BTML') serviceTypeDesiNEW = serviceTypeDesiML;
            if (document.MaintainClientForm.serviceType.value == 'BTCM') serviceTypeDesiNEW = serviceTypeDesiCM;
            if (document.MaintainClientForm.serviceType.value == 'BTAPP') serviceTypeDesiNEW = serviceTypeDesiAPP;
            if (document.MaintainClientForm.serviceType.value == 'BTTAP') serviceTypeDesiNEW = serviceTypeDesiTAP;

            var newAccountDesignation = '';
            if (document.MaintainClientForm.accountDesignation.value == '') {
                newAccountDesignation = '<'+serviceTypeDesiNEW;
            } else {
                if (document.MaintainClientForm.accountDesignation.value.indexOf(serviceTypeDesiOLD) != -1) {
                    newAccountDesignation = document.MaintainClientForm.accountDesignation.value.replace(serviceTypeDesiOLD,'');
                    if (newAccountDesignation.indexOf(serviceTypeDesiNEW) == -1){
                       newAccountDesignation = newAccountDesignation + serviceTypeDesiNEW;
                    }
                } else {
                   newAccountDesignation = document.MaintainClientForm.accountDesignation.value;
                }
            }
            document.MaintainClientForm.accountDesignation.value = newAccountDesignation;
        }

        function validateADForClientType(clientTypeSelect) {

           var serviceName = document.MaintainClientForm.serviceType.options[document.MaintainClientForm.serviceType.selectedIndex].value;
           var clientType = clientTypeSelect.options[clientTypeSelect.selectedIndex].value;

           if(serviceName == 'BTML') {
              if(clientType == 'I' || clientType == 'J') {
                  replaceAD();
                  document.MaintainClientForm.serviceTypeSave.value = document.MaintainClientForm.serviceType.value;
                  document.MaintainClientForm.accountDesignation.disabled = true;
                  document.MaintainClientForm.accountName.focus();
              } else {
                  document.MaintainClientForm.accountDesignation.disabled = false;
                  replaceAD();
              }
           }
           if(serviceName == 'BTGIP') {
              if(clientType == 'I' || clientType == 'J' || clientType == 'C') {
                  document.MaintainClientForm.accountDesignation.value = '';
                  document.MaintainClientForm.accountDesignation.disabled = true;
                  document.MaintainClientForm.accountName.focus();                
              } else {
                  document.MaintainClientForm.accountDesignation.disabled = false;
                  replaceAD();
              }
           }

           if(serviceName == 'BTPSP') {
                replaceAD();
           }
           if(serviceName == 'BTAPP') {
                replaceAD();
           }
           if(serviceName == 'BTCS') {
                replaceAD();
           }
           if(serviceName == 'BTCM') {
                replaceAD();
           }
           if(serviceName == 'BTTAP'){
                replaceAD();
           }
           document.MaintainClientForm.serviceTypeSave.value = document.MaintainClientForm.serviceType.value;
           return;
        }

