/**
 * Update the field list depending on the category selected
 *
 * @param CategObj  The option list object of the form which contains
 *                  the values for the categories
 * @param FieldObj  The option list object of the form which contains
 *                  the values for the fields
 */
function updateField(CategObj, FieldObj) {
   var category = CategObj.options[CategObj.selectedIndex].text;
   if (category == "Company Statistics") {
      FieldObj.length = 8;
      FieldObj.options[0].text = "Market Cap";
      FieldObj.options[1].text = "Industry";
      FieldObj.options[2].text = "Home Office State";
      FieldObj.options[3].text = "Employees";
      FieldObj.options[4].text = "GICS Sector";
      FieldObj.options[5].text = "GICS Industry Group";
      FieldObj.options[6].text = "52 Week High";
      FieldObj.options[7].text = "52 Week Low";
   } else if (category == "Value") {
      FieldObj.length = 8;
      FieldObj.options[0].text = "P/E Ratio";
      FieldObj.options[1].text = "P/E Growth ratio";
      FieldObj.options[2].text = "P/Book ratio";
      FieldObj.options[3].text = "Price";
      FieldObj.options[4].text = "P/E Ratio - Current";
      FieldObj.options[5].text = "P/E Ratio - Fcst Year 1";
      FieldObj.options[6].text = "P/E Ratio - Fcst Year 2";
      FieldObj.options[7].text = "P/Sales ratio";
   } else if (category == "Risk") {
      FieldObj.length = 8;
      FieldObj.options[0].text = "Earnings stability";
      FieldObj.options[1].text = "Capital adequacy ratio (banks)";
      FieldObj.options[2].text = "income cover  (industrials)";
      FieldObj.options[3].text = "Debt/equity ratio (industrials)";
      FieldObj.options[4].text = "Claims Solvency Ratio (insurance)";
      FieldObj.options[5].text = "Premium Solvency Ratio (insurance)";
      FieldObj.options[6].text = "Current Ratio (industrials)";
      FieldObj.options[7].text = "Quick Ratio (industrials)";
   } else if (category == "Growth") {
      FieldObj.length = 10;
      FieldObj.options[0].text = "Rev/share 1 yr. Growth";
      FieldObj.options[1].text = "Rev/share 5 yr. avg. growth";
      FieldObj.options[2].text = "EPS 1 yr. Growth";
      FieldObj.options[3].text = "EPS 5 yr. avg. growth";
      FieldObj.options[4].text = "EPS Fcst Yr 1 growth";
      FieldObj.options[5].text = "EPS Fcst Yr 2 growth";
      FieldObj.options[6].text = "EPS 2 yr. avg. forecast growth";
      FieldObj.options[7].text = "DPS 1 yr. Growth";
      FieldObj.options[8].text = "DPS 5 yr. avg. growth";
      FieldObj.options[9].text = "DPS 2 yr. avg. forecast growth";
   } else if (category == "Income") {
      FieldObj.length = 9;
      FieldObj.options[0].text = "Current DPS";
      FieldObj.options[1].text = "Franking";
      FieldObj.options[2].text = "Dividend Yield";
      FieldObj.options[3].text = "Div. Yield After Tax";
      FieldObj.options[4].text = "Div. Stability";
      FieldObj.options[5].text = "Div. payout ratio";
      FieldObj.options[6].text = "Div Yield - Current";
      FieldObj.options[7].text = "Div Yield - Fcst Year 1";
      FieldObj.options[8].text = "Div Yield - Fcst Year 2";
   } else if (category == "Performance Measures") {
      FieldObj.length = 5;
      FieldObj.options[0].text = "1 yr. Avg. annual return";
      FieldObj.options[1].text = "3 yr. Total  return";
      FieldObj.options[2].text = "5 yr. Avg. annual return";
      FieldObj.options[3].text = "10 yr. Avg. annual return";
      FieldObj.options[4].text = "Return on Equity";
   } else if (category == "Forecasts") {
      FieldObj.length = 6;
      FieldObj.options[0].text = "First Year EPS Fcst";
      FieldObj.options[1].text = "Second Year EPS Fcst";
      FieldObj.options[2].text = "First Year DPS Fcst";
      FieldObj.options[3].text = "Second Year DPS Fcst";
      FieldObj.options[4].text = "EPS 2 yr. avg. forecast growth";
      FieldObj.options[5].text = "DPS 2 yr. avg. forecast growth";
   }
   FieldObj.selectedIndex = [0];
}
