/**
 * Update the field list depending on the category selected
 *
 * @param CategObj  The option list object of the form which contains
 *                  the values for the categories
 * @param FieldObj  The option list object of the form which contains
 *                  the values for the fields
 */
function updateField(CategObj, FieldObj) {
   var category = CategObj.options[CategObj.selectedIndex].text;
   if (category == "Company Statistics") {
      FieldObj.length = 11;
      FieldObj.options[0].text = "Market Cap";
      FieldObj.options[1].text = "Indices";
      FieldObj.options[2].text = "Industry";
      FieldObj.options[3].text = "Home Office State";
      FieldObj.options[4].text = "Employees";
      FieldObj.options[5].text = "Price/NAB (invest/prop)";
      FieldObj.options[6].text = "shares outstanding";
      FieldObj.options[7].text = "GICS Sector";
      FieldObj.options[8].text = "GICS Industry Group";
      FieldObj.options[9].text = "52 Week High";
      FieldObj.options[10].text = "52 Week Low";
   } else if (category == "Value") {
      FieldObj.length = 10;
      FieldObj.options[0].text = "Value Rank";
      FieldObj.options[1].text = "Valuation ratio";
      FieldObj.options[2].text = "P/E Ratio";
      FieldObj.options[3].text = "P/E Growth ratio";
      FieldObj.options[4].text = "P/Book ratio";
      FieldObj.options[5].text = "Price";
      FieldObj.options[6].text = "P/E Ratio - Current";
      FieldObj.options[7].text = "P/E Ratio - Fcst Year 1";
      FieldObj.options[8].text = "P/E Ratio - Fcst Year 2";
      FieldObj.options[9].text = "P/Sales ratio";
   } else if (category == "Risk") {
      FieldObj.length = 12;
      FieldObj.options[0].text = "Risk Rank";
      FieldObj.options[1].text = "Beta";
      FieldObj.options[2].text = "Earnings stability";
      FieldObj.options[3].text = "Net Imp assets (banks)";
      FieldObj.options[4].text = "Net imp. assets/net assets (banks)";
      FieldObj.options[5].text = "Capital adequacy ratio (banks)";
      FieldObj.options[6].text = "income cover  (industrials)";
      FieldObj.options[7].text = "Debt/equity ratio (industrials)";
      FieldObj.options[8].text = "Claims Solvency Ratio (insurance)";
      FieldObj.options[9].text = "Premium Solvency Ratio (insurance)";
      FieldObj.options[10].text = "Current Ratio (industrials)";
      FieldObj.options[11].text = "Quick Ratio (industrials)";
   } else if (category == "Growth") {
      FieldObj.length = 26;
      FieldObj.options[0].text = "Growth Rank";
      FieldObj.options[1].text = "Rev/share 1 yr. Growth";
      FieldObj.options[2].text = "Rev/share 5 yr. avg. growth";
      FieldObj.options[3].text = "Rev/share 10 yr. avg. growth";
      FieldObj.options[4].text = "Cashflow/share 1 yr. Growth";
      FieldObj.options[5].text = "Cashflow/share 5 yr. avg. growth";
      FieldObj.options[6].text = "Cashflow/share 10 yr. avg. growth";
      FieldObj.options[7].text = "EPS 1 yr. Growth";
      FieldObj.options[8].text = "EPS 5 yr. avg. growth";
      FieldObj.options[9].text = "EPS 10 yr. avg. growth";
      FieldObj.options[10].text = "EPS 2 yr. avg. forecast growth";
      FieldObj.options[11].text = "DPS 1 yr. Growth";
      FieldObj.options[12].text = "DPS 5 yr. avg. growth";
      FieldObj.options[13].text = "DPS 10 yr. avg. growth";
      FieldObj.options[14].text = "DPS 2 yr. avg. forecast growth";
      FieldObj.options[15].text = "Book value/share 1 yr. Growth";
      FieldObj.options[16].text = "Book value/share 5 yr. avg. growth";
      FieldObj.options[17].text = "Book value/share 10 yr. avg. growth";
      FieldObj.options[18].text = "income/sh 1 yr. growth (banks)";
      FieldObj.options[19].text = "income/sh 5 yr. avg. growth (banks)";
      FieldObj.options[20].text = "income/sh 10 yr. avg. growth (banks)";
      FieldObj.options[21].text = "Assets/share 1 yr. growth (banks)";
      FieldObj.options[22].text = "Assets/share 5 yr. avg. growth (banks)";
      FieldObj.options[23].text = "Assets/share 10 yr. avg. growth (banks)";
      FieldObj.options[24].text = "EPS Fcst Yr 1 growth";
      FieldObj.options[25].text = "EPS Fcst Yr 2 growth";
   } else if (category == "Income") {
      FieldObj.length = 14;
      FieldObj.options[0].text = "Income Rank";
      FieldObj.options[1].text = "Current DPS";
      FieldObj.options[2].text = "Franking";
      FieldObj.options[3].text = "Dividend Yield";
      FieldObj.options[4].text = "Div. Yield After Tax";
      FieldObj.options[5].text = "Div. Stability";
      FieldObj.options[6].text = "Div. payout ratio";
      FieldObj.options[7].text = "Interim Ex Div. Date";
      FieldObj.options[8].text = "Interim Div. Pay Date";
      FieldObj.options[9].text = "Final Ex Div. Date";
      FieldObj.options[10].text = "Final Div. Pay Date";
      FieldObj.options[11].text = "Div Yield - Current";
      FieldObj.options[12].text = "Div Yield - Fcst Year 1";
      FieldObj.options[13].text = "Div Yield - Fcst Year 2";
   } else if (category == "Performance Measures") {
      FieldObj.length = 17;
      FieldObj.options[0].text = "1 yr. Avg. annual return";
      FieldObj.options[1].text = "3 yr. Total  return";
      FieldObj.options[2].text = "5 yr. Avg. annual return";
      FieldObj.options[3].text = "10 yr. Avg. annual return";
      FieldObj.options[4].text = "Return on Equity";
      FieldObj.options[5].text = "Net interest margin (Banks)";
      FieldObj.options[6].text = "Cost to income ratio (Banks)";
      FieldObj.options[7].text = "Return on Assets (Banks)";
      FieldObj.options[8].text = "Operating margin (industrials)";
      FieldObj.options[9].text = "Net profit margin (Industrials)";
      FieldObj.options[10].text = "Return on Capital (industrials)";
      FieldObj.options[11].text = "Loss ratio (Insurance)";
      FieldObj.options[12].text = "Expense ratio (Insurance)";
      FieldObj.options[13].text = "Combined ratio (Insurance)";
      FieldObj.options[14].text = "Return on investments (Insurance)";
      FieldObj.options[15].text = "Mgmt expense ratio (Investment)";
      FieldObj.options[16].text = "Mgmt expense ratio (property)";
   } else if (category == "Profit & Loss") {
      FieldObj.length = 26;
      FieldObj.options[0].text = "Operating revenue";
      FieldObj.options[1].text = "Depreciation";
      FieldObj.options[2].text = "Amortisation";
      FieldObj.options[3].text = "Net profit bef. Abnormals";
      FieldObj.options[4].text = "Net profit";
      FieldObj.options[5].text = "Tax rate";
      FieldObj.options[6].text = "Non interest income (banks)";
      FieldObj.options[7].text = "Net interest Income (banks)";
      FieldObj.options[8].text = "Invest. Income (Property)";
      FieldObj.options[9].text = "Other income (Property)";
      FieldObj.options[10].text = "Prop. expenses (Property)";
      FieldObj.options[11].text = "Rental Income (Property)";
      FieldObj.options[12].text = "Invest. income (Insurance)";
      FieldObj.options[13].text = "Net earned premium (insurance)";
      FieldObj.options[14].text = "Underwriting profit (insurance)";
      FieldObj.options[15].text = "Invest. income (investment)";
      FieldObj.options[16].text = "Current EPS";
      FieldObj.options[17].text = "Cashflow/share";
      FieldObj.options[18].text = "Sales/share";
      FieldObj.options[19].text = "Capital spending/share";
      FieldObj.options[20].text = "Book value/share";
      FieldObj.options[21].text = "EBIT";
      FieldObj.options[22].text = "Other income (Property)";
      FieldObj.options[23].text = "Rental Income (Property)";
      FieldObj.options[24].text = "Prop. expenses (Property)";
      FieldObj.options[25].text = "Invest. income (Insurance)";
   } else if (category == "Balance Sheet") {
      FieldObj.length = 21;
      FieldObj.options[0].text = "Total current assets";
      FieldObj.options[1].text = "Total current liabilities";
      FieldObj.options[2].text = "Total liabilities";
      FieldObj.options[3].text = "Preferred Stock";
      FieldObj.options[4].text = "Book value";
      FieldObj.options[5].text = "Cash (industrials)";
      FieldObj.options[6].text = "Inventories (industrials)";
      FieldObj.options[7].text = "Receivables (industrials)";
      FieldObj.options[8].text = "Accounts Payable (industrials)";
      FieldObj.options[9].text = "Short Term Debt (industrials)";
      FieldObj.options[10].text = "Long term debt (industrials)";
      FieldObj.options[11].text = "Percent Debt (industrials)";
      FieldObj.options[12].text = "Total Debt (industrials)";
      FieldObj.options[13].text = "Percent Equity (industrials)";
      FieldObj.options[14].text = "Deposits (banks)";
      FieldObj.options[15].text = "Loans (banks)";
      FieldObj.options[16].text = "% Interest Earning Assets (banks)";
      FieldObj.options[17].text = "Non interest-earning Assets (banks)";
      FieldObj.options[18].text = "Total assets (banks)";
      FieldObj.options[19].text = "Interest earning Assets (banks)";
      FieldObj.options[20].text = "Total liabilities (banks)";
   } else if (category == "Liquidity") {
      FieldObj.length = 2;
      FieldObj.options[0].text = "Annual turnover/total shares";
      FieldObj.options[1].text = "Top 20 Shareholder %";
   } else if (category == "Forecasts") {
      FieldObj.length = 12;
      FieldObj.options[0].text = "First Year Sales Fcst";
      FieldObj.options[1].text = "Second Year Sales Fcst";
      FieldObj.options[2].text = "First Year NPAT Fcst";
      FieldObj.options[3].text = "Second Year NPAT Fcst";
      FieldObj.options[4].text = "First Year EPS Fcst";
      FieldObj.options[5].text = "Second Year EPS Fcst";
      FieldObj.options[6].text = "First Year DPS Fcst";
      FieldObj.options[7].text = "Second Year DPS Fcst";
      FieldObj.options[8].text = "EPS 2 yr. avg. forecast growth";
      FieldObj.options[9].text = "DPS 2 yr. avg. forecast growth";
      FieldObj.options[10].text = "Earning Surprise %";
      FieldObj.options[11].text = "Average Recommendation";
   } else if (category == "Recommendation") {
      FieldObj.length = 1;
      FieldObj.options[0].text = "Recommendation";
   }
   FieldObj.selectedIndex = [0];
}
