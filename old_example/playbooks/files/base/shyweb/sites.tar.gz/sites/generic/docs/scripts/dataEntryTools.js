//************************************* Filters ********************************************

function addFilterUpperCase(ctrl){
    ctrl.attachEvent("onkeypress", filterUpperCaseKeyPress);
}

function filterUpperCaseKeyPress(){
    if(event && event.keyCode){
        var c = String.fromCharCode(event.keyCode);
        if(c.toUpperCase()!=c){
            event.keyCode = c.toUpperCase().charCodeAt(0);
        }
    }
}