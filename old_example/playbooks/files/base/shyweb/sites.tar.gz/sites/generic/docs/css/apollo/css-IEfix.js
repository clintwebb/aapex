// Determines whether OS is Mac or PC and call different css to fix iframes for dropdowns.
var sStyleFile;
if (navigator.appVersion.indexOf("Mac") != -1) {
    sStyleFile = "covermenu_formac.css"
} else {
    sStyleFile = "covermenu.css"
}
document.writeln('<link rel="stylesheet" type="text/css" href="/css/' + sStyleFile + '">');

// Determine operating system and browser name and version and sets widths and font sizes for Windows IE5 or 6.
var sBrowserName = navigator.userAgent.toLowerCase();

// Determine if browser is Internet Explorer
if (sBrowserName.indexOf('msie') != -1 &&
    sBrowserName.indexOf('opera') == -1 &&
    sBrowserName.indexOf('webtv') == -1) {

    var iVersion = parseFloat(sBrowserName.substring(sBrowserName.indexOf('msie ') + 5));

    // Determine if the version of Internet Explorer is version 5 and less than 7.
    if (parseInt(iVersion) >= 5 && parseInt(iVersion) < 7) {

        // Determine if we are running a windows system: 95, 98, NT, XP, etc.
        if (sBrowserName.indexOf('95') != -1 ||
            sBrowserName.indexOf('98') != -1 ||
            sBrowserName.indexOf('nt') != -1 ||
            sBrowserName.indexOf('win32') != -1 ||
            sBrowserName.indexOf('32bit') != -1 ||
            sBrowserName.indexOf('xp') != -1) {

            // If the above conditions are true then write the style.
            // Font-sizes should be one size less than in the westpac jdv-global.css file.
            document.writeln('<style type="text/css"><!-- ' +
                             '#public-leftColumn, #left-Column, #mainContent {width: 100%;} ' +
                             '.pagetitle, .pagetitle a, .pagetitle a:hover, .quote-heading {font-size: medium;} ' +
                             'h4, .publictitle, .login-trade-from {font-size: small;} ' +
                             'body, p, td, th, li, h3, input, select, .textfields input, .nav-main-heading, .nav-main-item, .nav-main-item a:link, .nav-main-item a:visited, .nav-main-item a:hover, .nav-main-item a:active, .nav-main-heading-disabled, .nav-main-item-disabled, td.nav-level-1-low a, td.nav-level-1-low a:active, td.nav-level-1-high, td.nav-level-1-disabled, td.nav-level-1-low a:hover, td.nav-level-2-low a, td.nav-level-2-low a:active, td.nav-level-2-high a, td.nav-level-2-high a:hover, td.nav-level-2-high a:active, td.nav-level-2-low a:hover {font-size: x-small;} ' +
                             '#footer, .disclaimer, .note, .note a:link, .note a:visited, .note a:hover, .note a:active, .note-plainlink, .note-plainlink a:link, .note-plainlink a:visited, .note-plainlink a:hover, .note-plainlink a:active {font-size: xx-small;} ' +
                             '.adobeNote {font-size: xx-small;} ' +
                             '.adobeNote a:link {font-size: xx-small;} ' +
                             '.adobeNote a:visited {font-size: xx-small;} ' +
                             '.adobeNote a:hover {font-size: xx-small;} ' +
                             '.adobeNote a:active {font-size: xx-small;} ' +
                             '.adobeNote a:active {font-size: xx-small;} ' +
                             'ul.group_items li {font-size: 110%;} ' +
                             '--></style>');
        }
    }
}
