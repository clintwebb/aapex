/* ==================================================================================================
   This function provides a cross-browser method for getting a handle on a named object.
   from http://quirksmode.org
   ================================================================================================ */
function getObj(name)
{
  if (document.getElementById)
  {
  	this.obj = document.getElementById(name);
	this.style = document.getElementById(name).style;
  }
  else if (document.all)
  {
	this.obj = document.all[name];
	this.style = document.all[name].style;
  }
  else if (document.layers)
  {
   	this.obj = document.layers[name];
   	this.style = document.layers[name];
  }
}

/* ==================================================================================================
   This function modifies the input value model data on the company research "value model" pages.
   ================================================================================================ */

function calvalue(BV, discrate, divpayout, eps1, eps2, lngtmF, avgROE) {

    //Make sure they are of type number
    if (BV.substring(0, 1) == '$'){
        BV = Number(BV.substring(1));
     } else {
        BV = BV*1;
     }

    if(isNaN(BV) == true) {
        alert('Book value per share is not a number.');
        return;
    }

    if (discrate.substring(discrate.length - 1) == '%'){
        discrate = Number(discrate.substring(0, discrate.length - 1));
    } else {
        discrate = discrate * 1;

    }

    if(isNaN(discrate) == true) {
        modvalue.innerText="";
        alert('Discount rate is not a number.');
        return;
    } else {
        discrate = discrate * 0.01;
    }

    if (divpayout.substring(divpayout.length - 1) == '%'){
        divpayout = Number(divpayout.substring(0, divpayout.length - 1));
    } else {
        divpayout = divpayout * 1;
    }

    if(isNaN(divpayout) == true) {
        modvalue.innerText="";
        alert('Dividend payout ratio is not a number.');
        return;
    } else {
        divpayout = divpayout * 0.01;
    }

    if (eps1.substring(0, 1) == '$'){
        eps1 = Number(eps1.substring(1));
    } else {
        eps1 = eps1 * 1;  //need to do this to convert to number
    }

    if(isNaN(eps1) == true) {
        modvalue.innerText="";
        alert('First year forecast EPS is not a number.');
        return;
    }

    if (eps2.substring(0, 1) == '$'){
        eps2 = Number(eps2.substring(1));
    } else {
        eps2 = eps2 * 1;
    }

    if(isNaN(eps2) == true) {
        modvalue.innerText='';
        alert('Second year forecast EPS is not a number.');
        return;
    }

    if (lngtmF.substring(lngtmF.length - 1) == '%'){
        lngtmF = Number(lngtmF.substring(0, lngtmF.length - 1));
    } else {
        lngtmF = lngtmF * 1;
    }

    if(isNaN(lngtmF) == true) {
        modvalue.innerText="";
        alert('Long term EPS growth rate is not a number.');
        return;
    } else {
        lngtmF = lngtmF * 0.01;
    }

    if (avgROE.substring(avgROE.length - 1) == '%'){
        avgROE = Number(avgROE.substring(0, avgROE.length - 1));
    } else {
        avgROE = avgROE * 1;
    }

    if(isNaN(avgROE) == true) {
        modvalue.innerText="";
        alert('Long term industry average return on equity is not a number.');
        return;
    } else {
        avgROE = avgROE * 0.01;
    }

    var roe, pbcum, cg, feps, BVOrig, ROEY8, aspectModelNew;
    BVOrig = BV;

    //year 1
    roe = eps1 / BV;
    pbcum = 1 + (roe - discrate) / (1 + discrate);
    cg = 1;

    //year 2
    BV = BV + (eps1 * (1 - divpayout));
    cg = cg * (1 + (1 - divpayout) * roe);
    roe = eps2 / BV;
    pbcum = (((roe - discrate) * cg) / Math.pow((1 + discrate), 2)) + pbcum;

    //from year 3 to year 7 use the long term growth rate forecast to grow eps each year
    feps = eps2;
    for ( i=3; i<8; i++) {
      BV = (BV + feps * (1 - divpayout));
      feps = feps * (1 + lngtmF);
      cg = cg * (1 + (1 - divpayout) * roe);
      roe = feps / BV;
      pbcum = (roe - discrate) * cg / Math.pow((1 + discrate), i) + pbcum;
    }

    // from years 8 through 15 gradually adjust ROE from year 7 level to long term industry ROE
    ROEY8 = roe;
    for ( i=8; i<16; i++) {
      cg = cg * (1 + (1 - divpayout) * roe);
      roe = roe - ((ROEY8 - avgROE) / 8);
      pbcum = (roe - discrate) * cg / Math.pow((1 + discrate), i) + pbcum;
    }

    // use perpetuity at year fifteen.  assume abnormal roe at year 15 continues in perpetuity
    aspectModelNew = BVOrig * (pbcum + ((roe - discrate) * cg) / (discrate *( Math.pow((1 + discrate), 15))));

    var modvalue = new getObj('modvalue').obj;
    modvalue.innerHTML = "$" + Math.round(aspectModelNew * 1000)/1000;
}