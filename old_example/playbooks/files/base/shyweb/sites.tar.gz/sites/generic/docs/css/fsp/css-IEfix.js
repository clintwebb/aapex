
//Determines whether OS is Mac or PC and call different css to fix iframes for dropdowns
var sStyleFile;
if ( navigator.appVersion.indexOf("Mac")!=-1 ) {
    sStyleFile = "covermenu_formac.css"
}
else {
    sStyleFile = "covermenu.css"
}
document.writeln('<link rel="stylesheet" type="text/css" href="/css/' + sStyleFile + '">');


// Determine operating system and browser name and version and sets width on #public-leftColumn for Windows IE5+
var sBrowserName;
var iVersion;

sBrowserName = navigator.userAgent.toLowerCase();

//Determine if browser is Internet Explorer
if ( sBrowserName.indexOf('msie') != -1 && (sBrowserName.indexOf('opera') == -1) && (sBrowserName.indexOf('webtv') == -1) ) {
iVersion = parseFloat( sBrowserName.substring( sBrowserName.indexOf('msie ') + 5 ) );
    //Determine if the version of Internet Explorer is between 5 and 7 - excluding 7...
    if ( parseInt(iVersion) >= 5 && parseInt(iVersion) < 7 ) {
        //Determine if we are running a windows system: 95,98,NT,XP etc.
        if ( sBrowserName.indexOf('95') != -1 || sBrowserName.indexOf('98') != -1 || sBrowserName.indexOf('nt') != -1 || sBrowserName.indexOf('win32') != -1 || sBrowserName.indexOf('32bit') != -1 || sBrowserName.indexOf('xp') != -1 ) {
            //If the above conditions are true then write the style
            document.writeln('<style type="text/css"><!--#public-leftColumn {width: 100%;} #left-Column {width: 100%;} --></style>');
        }
    }
}
