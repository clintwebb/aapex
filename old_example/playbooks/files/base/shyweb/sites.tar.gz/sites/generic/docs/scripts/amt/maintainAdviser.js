        function disableFields() {

           var country = document.MaintainAdviserForm.country.options[document.MaintainAdviserForm.country.selectedIndex].value;

           if(country != 'AUS') {
              document.MaintainAdviserForm.state.selectedIndex = 0;
              document.MaintainAdviserForm.state.options[document.MaintainAdviserForm.state.selectedIndex].value = 0;
              document.MaintainAdviserForm.state.disabled = true;
           }
        }

        function checkState(countrySelect) {

           var country = countrySelect.options[countrySelect.selectedIndex].value;

           if(country != 'AUS') {
              document.MaintainAdviserForm.state.selectedIndex = 0;
              document.MaintainAdviserForm.state.options[document.MaintainAdviserForm.state.selectedIndex].value = 0;
              document.MaintainAdviserForm.state.disabled = true;
              alert("You are entering an overseas address. Please make sure the postcode and address details are correct for the country you have selected.");
           } else {
              document.MaintainAdviserForm.state.disabled = false;
           }
        }