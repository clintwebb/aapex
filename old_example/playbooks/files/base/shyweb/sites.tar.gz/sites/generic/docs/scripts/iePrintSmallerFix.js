/* Attach a different stylesheet for IE */

var isIE = false;

//Determine if browser is Internet Explorer
if ( sBrowserName.indexOf('msie') != -1 && (sBrowserName.indexOf('opera') == -1) && (sBrowserName.indexOf('webtv') == -1) ) {
iVersion = parseFloat( sBrowserName.substring( sBrowserName.indexOf('msie ') + 5 ) );
    //Determine if the version of Internet Explorer is version 5 or above
    if ( parseInt(iVersion) >= 5 ) {
        isIE = true;
    }
}


if (isIE) {
  //document.writeln('<link rel="stylesheet" type="text/css" media="print" href="/css/jdv-printoverride-smaller.css">');
  document.writeln('<style type="text/css" media="print">');
  document.writeln('@page {size: landscape; }');
  document.writeln(' td, .tableborder th, .navButton {');
  document.writeln('  font-size: 55%;');
  document.writeln(' #mainContent {');
  document.writeln('  width: 100%;');
  document.writeln('}');
  document.writeln('</style>');
}