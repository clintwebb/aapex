<!--//--><![CDATA[//><!--
function menuFix() {
    // try catch compatibility so that fails silently if no menu is in place, which can be valid in some pages, ie entrust home page
    try {
        var sfEls = document.getElementById("nav").getElementsByTagName("LI");
        for (var i=0; i<sfEls.length; i++) {
            sfEls[i].onmouseover=function() {
            this.className+=(this.className.length>0? " ": "") + "sfhover";
            }
            // event added to keep menu items from disappearing
            sfEls[i].onMouseDown=function() {
            this.className+=(this.className.length>0? " ": "") + "sfhover";
            }
            // event added to keep menu items from disappearing
            sfEls[i].onMouseUp=function() {
            this.className+=(this.className.length>0? " ": "") + "sfhover";
            }
            sfEls[i].onmouseout=function() {
            this.className=this.className.replace(new RegExp("( ?|^)sfhover\\b"), "");
            }
        }
        RolloverMenuRunning();
    } catch (e){
        // no worries, just menus not here ....
    }
}

/*************************************
Description:	Rollover Menu Running
Author:			Joshua Chen
Date:			2004/07/14

Modified:		Keegan Rowe
Date:			31/08/2005
Changes:		Modifications to suit
				my requirements.
*************************************/
RolloverMenuRunning	 = function(){
	//Only continue if we are able to retrieve the elements of the document by their ID attribute
	if (document.all && document.getElementById){
		//Locate the 'Nav' ID
		if (document.getElementById("nav")){
			var navRoot = document.getElementById("nav");
			var node, node2, node3, node4;
			//Loop through all the children of the 'Nav' ID
			for (i=0; i<navRoot.childNodes.length; i++){
				node = navRoot.childNodes[i];
				//Loop through all the children of the current tag
				for (var j=0; j<node.childNodes.length; j++) {						
					//Only proceed further into the structure if we are currently looking at a 'LI' tag
					if (node.childNodes[j].nodeName == "LI") {
						node2 = node.childNodes[j];
						//Loop through all the children of the current LI tag
						for (var k=0; k<node2.childNodes.length; k++) {
							//Only proceed further into the structure if we are currently looking at a 'UL' tag
							if (node2.childNodes[k].nodeName == "UL") {	
								//Examine the first child of this tag, if it has properties of width and height equal to zero then proceed
								if ( node2.childNodes[k].childNodes[0].style.width == "0px" && node2.childNodes[k].childNodes[0].style.height == "0px"){
									//Retrieve the width and height of the 'UL' tag that we are currently in
									var menuWidth	= node2.childNodes[k].offsetWidth;
									var menuHeight	= node2.childNodes[k].offsetHeight;
									if (typeof(menuWidth) == "number" && typeof(menuHeight) == "number"){
										//Set the iframe object to have the same height and width as the UL, but only if they are valid numbers
										node2.childNodes[k].childNodes[0].style.width = menuWidth;
										node2.childNodes[k].childNodes[0].style.height = menuHeight;
									}
								}
								node3 = node2.childNodes[k];
								//Continue searching for a 3rd level
								for (var l=0; l<node3.childNodes.length; l++) {
									//Only proceed further into the structure if we are currently looking at a 'LI' tag
									if (node3.childNodes[l].nodeName == "LI") {
										node4 = node3.childNodes[l];
										//Loop through all the children of the current LI tag
										for (var m=0; m<node4.childNodes.length; m++) {
											//Only proceed further into the structure if we are currently looking at a 'UL' tag
											if (node4.childNodes[m].nodeName == "UL") {
												//Examine the first child of this tag, if it has properties of width and height equal to zero then proceed
												if ( node4.childNodes[m].childNodes[0].style.width == "0px" && node4.childNodes[m].childNodes[0].style.height == "0px"){
													//Retrieve the width and height of the 'UL' tag that we are currently in
													var menuWidth	= node4.childNodes[m].offsetWidth;
													var menuHeight	= node4.childNodes[m].offsetHeight;
													if (typeof(menuWidth) == "number" && typeof(menuHeight) == "number"){
														//Set the iframe object to have the same height and width as the UL, but only if they are valid numbers
														node4.childNodes[m].childNodes[0].style.width = menuWidth;
														node4.childNodes[m].childNodes[0].style.height = menuHeight;
													}
												}											
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

addLoadEvent(menuFix);
//--><!]]>

